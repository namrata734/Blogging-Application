import React from "react";
import Posts from "../../posts/posts";
import "./post.css";

const Post = () => {
  return (
    <div className="post">
      <Posts />
      <Posts />
      <Posts />
      <Posts />
      <Posts />
      <Posts />
      <Posts />
      <Posts />
      <Posts />
      <Posts />
    </div>
  );
};

export default Post;
